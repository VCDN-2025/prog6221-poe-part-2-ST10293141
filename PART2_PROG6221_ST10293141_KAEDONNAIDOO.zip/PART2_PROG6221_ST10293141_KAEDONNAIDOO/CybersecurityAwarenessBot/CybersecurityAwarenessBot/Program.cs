﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Threading;
using System.IO;

namespace CybersecurityAwarenessBot
{
    class Program
    {
        // User information storage for memory feature
        private static Dictionary<string, string> userMemory = new Dictionary<string, string>();
        private static string userName = "";

        // Keyword responses dictionary
        private static Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>
        {
            ["password"] = new List<string>
            {
                "Strong passwords are your first line of defense! Use at least 12 characters with a mix of uppercase, lowercase, numbers, and symbols.",
                "Never reuse passwords across multiple accounts. Consider using a password manager to keep track of unique passwords.",
                "Avoid using personal information like birthdays, names, or addresses in your passwords. Hackers can easily guess these!",
                "Enable two-factor authentication (2FA) whenever possible - it adds an extra layer of security to your accounts."
            },
            ["phishing"] = new List<string>
            {
                "Be cautious of emails asking for personal information. Legitimate companies will never ask for passwords via email.",
                "Check the sender's email address carefully - scammers often use addresses that look similar to real companies.",
                "Look for spelling and grammar mistakes in emails - these are often signs of phishing attempts.",
                "When in doubt, contact the company directly through their official website or phone number, not through the suspicious email."
            },
            ["scam"] = new List<string>
            {
                "If something seems too good to be true, it probably is! Be wary of 'get rich quick' schemes and unrealistic offers.",
                "Scammers often create a sense of urgency. Take time to think before acting on suspicious requests.",
                "Never give out personal information to unsolicited callers or emails, even if they claim to be from your bank.",
                "Report suspected scams to the South African Banking Risk Information Centre (SABRIC) or local authorities."
            },
            ["privacy"] = new List<string>
            {
                "Review your social media privacy settings regularly. Limit who can see your personal information and posts.",
                "Be careful about what you share online - once it's posted, it can be difficult to completely remove.",
                "Use privacy-focused search engines and browsers to reduce tracking of your online activities.",
                "Read privacy policies before agreeing to them, especially for apps and services that handle sensitive data."
            },
            ["malware"] = new List<string>
            {
                "Keep your antivirus software updated and run regular scans to detect and remove malicious software.",
                "Avoid downloading software from untrusted sources. Stick to official app stores and verified websites.",
                "Be cautious when clicking on links or downloading attachments from unknown sources.",
                "Keep your operating system and software updated - patches often fix security vulnerabilities."
            },
            ["wifi"] = new List<string>
            {
                "Avoid using public Wi-Fi for sensitive activities like online banking or shopping.",
                "If you must use public Wi-Fi, consider using a VPN to encrypt your internet connection.",
                "Turn off automatic Wi-Fi connection on your devices to prevent connecting to malicious hotspots.",
                "Set up a guest network at home for visitors to keep your main network secure."
            }
        };

        // General conversation responses
        private static Dictionary<string, List<string>> generalResponses = new Dictionary<string, List<string>>
        {
            ["greeting"] = new List<string>
            {
                "Hello there! I'm doing great and ready to help you stay safe online!",
                "Hi! I'm here and excited to share cybersecurity knowledge with you!",
                "Greetings! I'm functioning perfectly and ready to boost your cyber awareness!"
            },
            ["purpose"] = new List<string>
            {
                "I'm here to help South African citizens stay safe online! I can provide tips on passwords, phishing, privacy, and more.",
                "My mission is to educate people about cybersecurity threats and how to protect themselves in our digital world.",
                "I'm your personal cybersecurity advisor, here to help you navigate the online world safely!"
            },
            ["help"] = new List<string>
            {
                "I can help you with topics like: passwords, phishing, scams, privacy, malware, Wi-Fi security, and general online safety.",
                "Ask me about any cybersecurity topic! I'm knowledgeable about phishing, password security, privacy protection, and much more.",
                "I'm here to answer questions about staying safe online. Try asking about passwords, scams, or any security concerns you have!"
            }
        };

        static void Main(string[] args)
        {
            // Initialize console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Play voice greeting (simulate with text since we can't actually play audio in console)
            PlayVoiceGreeting();

            // Display ASCII logo
            DisplayLogo();

            // Get user's name and start conversation
            GetUserName();

            // Main conversation loop
            StartConversation();
        }

        static void PlayVoiceGreeting()
        {
            SetConsoleColor(ConsoleColor.Cyan);
            Console.WriteLine(" Playing voice greeting...");
            Thread.Sleep(1000); // Simulate audio playback delay
            Console.WriteLine(" \"Hello! Welcome to the Cybersecurity Awareness Bot. I'm here to help you stay safe online.\"");
            Thread.Sleep(2000);
            Console.ResetColor();
        }

        static void DisplayLogo()
        {
            SetConsoleColor(ConsoleColor.Green);
            Console.WriteLine(@"
╔═══════════════════════════════════════════════════════════════════════════════╗
║ ║
║ ████████╗██╗ ██╗██████╗ ███████╗██████╗ ███████╗███████╗ ██████╗ ║
║ ╚══██╔══╝██║ ██║██╔══██╗██╔════╝██╔══██╗██╔════╝██╔════╝██╔════╝ ║
║ ██║ ███████║██████╔╝█████╗ ██████╔╝███████╗█████╗ ██║ ║
║ ██║ ██╔══██║██╔══██╗██╔══╝ ██╔══██╗╚════██║██╔══╝ ██║ ║
║ ██║ ██║ ██║██║ ██║███████╗██║ ██║███████║███████╗╚██████╗ ║
║ ╚═╝ ╚═╝ ╚═╝╚═╝ ╚═╝╚══════╝╚═╝ ╚═╝╚══════╝╚══════╝ ╚═════╝ ║
║ ║
║ ██████╗██╗ ██╗██████╗ ███████╗██████╗ ██████╗ ██████╗ ║
║ ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗ ║
║ ██║ ╚████╔╝ ██████╔╝█████╗ ██████╔╝██████╔╝██║ ██║ ║
║ ██║ ╚██╔╝ ██╔══██╗██╔══╝ ██╔══██╗██╔══██╗██║ ██║ ║
║ ╚██████╗ ██║ ██████╔╝███████╗██║ ██║██████╔╝╚██████╔╝ ║
║ ╚═════╝ ╚═╝ ╚═════╝ ╚══════╝╚═╝ ╚═╝╚═════╝ ╚═════╝ ║
║ ║
║ 🛡️ CYBERSECURITY AWARENESS BOT 🛡️ ║
║ Protecting South African Citizens ║
║ ║
╚═══════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
        }

        static void GetUserName()
        {
            SetConsoleColor(ConsoleColor.Yellow);
            TypewriterEffect(" Hello! I'm your Cybersecurity Awareness Assistant.");
            Console.WriteLine();
            TypewriterEffect(" I'm here to help you stay safe in South Africa's digital landscape.");
            Console.WriteLine();
            Console.ResetColor();

            Console.Write(" What's your name? ");
            userName = Console.ReadLine()?.Trim();

            while (string.IsNullOrEmpty(userName))
            {
                SetConsoleColor(ConsoleColor.Red);
                Console.WriteLine(" Please enter a valid name.");
                Console.ResetColor();
                Console.Write(" What's your name? ");
                userName = Console.ReadLine()?.Trim();
            }

            userMemory["name"] = userName;

            SetConsoleColor(ConsoleColor.Green);
            TypewriterEffect($" Nice to meet you, {userName}! I'm excited to help you become more cyber-aware.");
            Console.WriteLine();
            Console.ResetColor();
        }

        static void StartConversation()
        {
            SetConsoleColor(ConsoleColor.Cyan);
            TypewriterEffect(" You can ask me about cybersecurity topics like passwords, phishing, scams, privacy, and more!");
            TypewriterEffect(" Try saying things like 'tell me about passwords' or 'how can I avoid scams'");
            TypewriterEffect(" Type 'quit', 'exit', or 'bye' to end our conversation.");
            Console.WriteLine();
            Console.ResetColor();

            while (true)
            {
                Console.Write($" {userName}: ");
                string userInput = Console.ReadLine()?.Trim().ToLower();

                if (string.IsNullOrEmpty(userInput))
                {
                    SetConsoleColor(ConsoleColor.Yellow);
                    Console.WriteLine(" I didn't catch that. Could you please say something?");
                    Console.ResetColor();
                    continue;
                }

                // Check for exit commands
                if (IsExitCommand(userInput))
                {
                    SetConsoleColor(ConsoleColor.Green);
                    TypewriterEffect($" Thanks for chatting, {userName}! Stay safe online and remember what we discussed!");
                    TypewriterEffect(" Keep your digital life secure! Goodbye!");
                    Console.ResetColor();
                    break;
                }

                // Process user input and generate response
                string response = ProcessUserInput(userInput);

                SetConsoleColor(ConsoleColor.Magenta);
                Console.Write(" CyberBot: ");
                Console.ResetColor();
                TypewriterEffect(response);
                Console.WriteLine();
            }
        }

        static string ProcessUserInput(string input)
        {
            // Detect sentiment first
            string sentiment = DetectSentiment(input);

            // Check for cybersecurity keywords
            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    // Store user interest in memory
                    if (!userMemory.ContainsKey("interests"))
                        userMemory["interests"] = "";

                    if (!userMemory["interests"].Contains(keyword))
                    {
                        userMemory["interests"] += keyword + ",";
                    }

                    string response = GetRandomResponse(keywordResponses[keyword]);
                    return AdjustResponseForSentiment(response, sentiment, keyword);
                }
            }

            // Check for general conversation patterns
            if (IsGreeting(input))
            {
                return GetRandomResponse(generalResponses["greeting"]);
            }

            if (IsPurposeQuery(input))
            {
                return GetRandomResponse(generalResponses["purpose"]);
            }

            if (IsHelpQuery(input))
            {
                return GetRandomResponse(generalResponses["help"]);
            }

            // Check for memory-related queries
            if (input.Contains("remember") || input.Contains("interested"))
            {
                return HandleMemoryQuery();
            }

            // Default response for unrecognized input
            return GetDefaultResponse(sentiment);
        }

        static string DetectSentiment(string input)
        {
            if (input.Contains("worried") || input.Contains("scared") || input.Contains("afraid") ||
                input.Contains("concerned") || input.Contains("anxious"))
                return "worried";

            if (input.Contains("frustrated") || input.Contains("annoyed") || input.Contains("angry"))
                return "frustrated";

            if (input.Contains("curious") || input.Contains("interested") || input.Contains("want to know"))
                return "curious";

            if (input.Contains("confused") || input.Contains("don't understand") || input.Contains("unclear"))
                return "confused";

            return "neutral";
        }

        static string AdjustResponseForSentiment(string baseResponse, string sentiment, string topic)
        {
            switch (sentiment)
            {
                case "worried":
                    return $"I understand your concerns about {topic} - it's completely normal to feel worried about online security. {baseResponse} Remember, being cautious is a good thing!";

                case "frustrated":
                    return $"I can sense you might be feeling frustrated about {topic}. Don't worry - cybersecurity can be overwhelming, but we'll take it step by step. {baseResponse}";

                case "curious":
                    return $"Great question about {topic}! I love your curiosity - it's the key to staying safe online. {baseResponse} Feel free to ask more questions!";

                case "confused":
                    return $"No worries if {topic} seems confusing - let me break it down for you. {baseResponse} Does this help clarify things?";

                default:
                    return baseResponse;
            }
        }

        static string HandleMemoryQuery()
        {
            if (userMemory.ContainsKey("interests") && !string.IsNullOrEmpty(userMemory["interests"]))
            {
                string[] interests = userMemory["interests"].TrimEnd(',').Split(',');
                string interestsList = string.Join(", ", interests);
                return $"I remember you've shown interest in: {interestsList}. These are all important cybersecurity topics! Is there anything specific about these areas you'd like to explore further?";
            }
            else
            {
                return "We haven't discussed any specific cybersecurity topics yet. What would you like to learn about?";
            }
        }

        static bool IsGreeting(string input)
        {
            return input.Contains("hello") || input.Contains("hi") || input.Contains("hey") ||
                   input.Contains("how are you") || input.Contains("good morning") ||
                   input.Contains("good afternoon") || input.Contains("good evening");
        }

        static bool IsPurposeQuery(string input)
        {
            return input.Contains("purpose") || input.Contains("what do you do") ||
                   input.Contains("who are you") || input.Contains("what are you");
        }

        static bool IsHelpQuery(string input)
        {
            return input.Contains("help") || input.Contains("what can") ||
                   input.Contains("topics") || input.Contains("ask about");
        }

        static bool IsExitCommand(string input)
        {
            return input == "quit" || input == "exit" || input == "bye" ||
                   input == "goodbye" || input == "stop";
        }

        static string GetRandomResponse(List<string> responses)
        {
            Random random = new Random();
            return responses[random.Next(responses.Count)];
        }

        static string GetDefaultResponse(string sentiment)
        {
            List<string> defaultResponses = new List<string>
            {
                "I'm not sure I understand that topic. Could you try rephrasing or asking about cybersecurity topics like passwords, phishing, or privacy?",
                "That's interesting, but I specialize in cybersecurity topics. Try asking me about online safety, scams, or digital privacy!",
                "I didn't quite catch that. I'm here to help with cybersecurity awareness - feel free to ask about staying safe online!",
                "Could you rephrase that? I'm focused on helping with cybersecurity topics like password security, avoiding scams, and protecting your privacy."
            };

            string response = GetRandomResponse(defaultResponses);

            if (sentiment == "frustrated")
            {
                return "I can sense you might be feeling frustrated. " + response + " I'm here to help make cybersecurity easier to understand!";
            }

            return response;
        }

        static void TypewriterEffect(string text, int delay = 30)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }

        static void SetConsoleColor(ConsoleColor color)
        {
            Console.ForegroundColor = color;
        }
    }
}